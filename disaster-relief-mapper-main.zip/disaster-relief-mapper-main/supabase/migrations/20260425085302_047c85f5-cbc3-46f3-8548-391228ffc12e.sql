
-- Assessments: uploaded images with analysis
CREATE TABLE public.assessments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  image_url TEXT NOT NULL,
  location_name TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  zones JSONB NOT NULL DEFAULT '[]'::jsonb,
  rescue_path JSONB NOT NULL DEFAULT '[]'::jsonb,
  severity_score INTEGER NOT NULL DEFAULT 0,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view assessments"
  ON public.assessments FOR SELECT USING (true);

CREATE POLICY "Anyone can create assessments"
  ON public.assessments FOR INSERT WITH CHECK (true);

-- SOS reports from victims
CREATE TABLE public.sos_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  people_count INTEGER NOT NULL DEFAULT 1,
  situation TEXT NOT NULL,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  location_name TEXT,
  status TEXT NOT NULL DEFAULT 'pending',
  assessment_id UUID REFERENCES public.assessments(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.sos_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view sos reports"
  ON public.sos_reports FOR SELECT USING (true);

CREATE POLICY "Anyone can create sos reports"
  ON public.sos_reports FOR INSERT WITH CHECK (true);

-- Shelters / helplines / hospitals
CREATE TABLE public.shelters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  type TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  capacity INTEGER,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.shelters ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can view shelters"
  ON public.shelters FOR SELECT USING (true);

-- Storage bucket for uploaded disaster images
INSERT INTO storage.buckets (id, name, public)
VALUES ('disaster-images', 'disaster-images', true);

CREATE POLICY "Public can view disaster images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'disaster-images');

CREATE POLICY "Anyone can upload disaster images"
  ON storage.objects FOR INSERT
  WITH CHECK (bucket_id = 'disaster-images');
