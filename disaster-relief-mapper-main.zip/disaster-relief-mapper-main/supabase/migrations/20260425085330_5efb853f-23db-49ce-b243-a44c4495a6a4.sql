
-- Length & sanity limits on assessments
ALTER TABLE public.assessments
  ADD CONSTRAINT assessments_image_url_len CHECK (char_length(image_url) <= 2000),
  ADD CONSTRAINT assessments_location_name_len CHECK (location_name IS NULL OR char_length(location_name) <= 200),
  ADD CONSTRAINT assessments_notes_len CHECK (notes IS NULL OR char_length(notes) <= 2000),
  ADD CONSTRAINT assessments_severity_range CHECK (severity_score BETWEEN 0 AND 100),
  ADD CONSTRAINT assessments_lat_range CHECK (latitude IS NULL OR (latitude BETWEEN -90 AND 90)),
  ADD CONSTRAINT assessments_lng_range CHECK (longitude IS NULL OR (longitude BETWEEN -180 AND 180));

-- Length & sanity limits on SOS reports
ALTER TABLE public.sos_reports
  ADD CONSTRAINT sos_full_name_len CHECK (char_length(full_name) BETWEEN 1 AND 120),
  ADD CONSTRAINT sos_phone_len CHECK (char_length(phone) BETWEEN 4 AND 20),
  ADD CONSTRAINT sos_situation_len CHECK (char_length(situation) BETWEEN 1 AND 1000),
  ADD CONSTRAINT sos_location_name_len CHECK (location_name IS NULL OR char_length(location_name) <= 200),
  ADD CONSTRAINT sos_people_count_range CHECK (people_count BETWEEN 1 AND 1000),
  ADD CONSTRAINT sos_lat_range CHECK (latitude IS NULL OR (latitude BETWEEN -90 AND 90)),
  ADD CONSTRAINT sos_lng_range CHECK (longitude IS NULL OR (longitude BETWEEN -180 AND 180));

-- Replace storage SELECT policy: only allow fetching individual objects, not listing the bucket
DROP POLICY "Public can view disaster images" ON storage.objects;

CREATE POLICY "Public can read individual disaster images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'disaster-images' AND name IS NOT NULL);
