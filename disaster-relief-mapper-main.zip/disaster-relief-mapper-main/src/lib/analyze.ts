// Simulated damage-zone analyzer.
// We sample brightness/color of the uploaded image to *deterministically* place
// red/yellow/green ellipses and a rescue path. Coordinates are in PERCENT
// (0-100) so they scale with any image size — never pixels.

export type Zone = {
  severity: "high" | "med" | "low";
  cx: number; // %
  cy: number; // %
  rx: number; // %
  ry: number; // %
  rotate: number; // deg
  label: string;
};

export type RescuePoint = { x: number; y: number };

export type AnalysisResult = {
  zones: Zone[];
  rescuePath: RescuePoint[];
  severityScore: number; // 0-100
};

function hashSeed(str: string): number {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) {
    h ^= str.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

function mulberry32(seed: number) {
  let a = seed;
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Quickly samples the image on a small canvas to find the darkest, mid, and
 * brightest regions. We call darker → more debris/destruction (high severity).
 */
export async function analyzeImage(file: File): Promise<AnalysisResult> {
  const url = URL.createObjectURL(file);
  try {
    const img = await loadImage(url);
    const GRID = 8;
    const canvas = document.createElement("canvas");
    canvas.width = GRID;
    canvas.height = GRID;
    const ctx = canvas.getContext("2d")!;
    ctx.drawImage(img, 0, 0, GRID, GRID);
    const data = ctx.getImageData(0, 0, GRID, GRID).data;

    type Cell = { x: number; y: number; lum: number };
    const cells: Cell[] = [];
    for (let y = 0; y < GRID; y++) {
      for (let x = 0; x < GRID; x++) {
        const i = (y * GRID + x) * 4;
        const lum = 0.299 * data[i] + 0.587 * data[i + 1] + 0.114 * data[i + 2];
        cells.push({ x, y, lum });
      }
    }
    cells.sort((a, b) => a.lum - b.lum);

    const seed = hashSeed(`${file.name}-${file.size}`);
    const rand = mulberry32(seed);

    const cellToPct = (c: Cell) => ({
      cx: ((c.x + 0.5 + (rand() - 0.5) * 0.6) / GRID) * 100,
      cy: ((c.y + 0.5 + (rand() - 0.5) * 0.6) / GRID) * 100,
    });

    // Darkest 2 → high, middle 2 → med, brightest 2 → low
    const high = cells.slice(0, 2).map((c) => ({
      ...cellToPct(c),
      severity: "high" as const,
      rx: 14 + rand() * 6,
      ry: 10 + rand() * 5,
      rotate: rand() * 60 - 30,
      label: "Severe damage",
    }));
    const mid = cells.slice(GRID * GRID / 2 - 1, GRID * GRID / 2 + 1).map((c) => ({
      ...cellToPct(c),
      severity: "med" as const,
      rx: 12 + rand() * 5,
      ry: 9 + rand() * 4,
      rotate: rand() * 60 - 30,
      label: "Moderate damage",
    }));
    const low = cells.slice(-2).map((c) => ({
      ...cellToPct(c),
      severity: "low" as const,
      rx: 11 + rand() * 4,
      ry: 8 + rand() * 4,
      rotate: rand() * 60 - 30,
      label: "Safer area",
    }));

    const zones: Zone[] = [...high, ...mid, ...low];

    // Rescue path: start from a low-severity zone, weave around high-severity
    // ones, end at the safest cell (highest brightness).
    const safe = low[0];
    const rescuePath: RescuePoint[] = [
      { x: 5, y: 95 },
      { x: 25, y: 80 - rand() * 10 },
      { x: 45, y: 60 + rand() * 10 },
      { x: 65, y: 40 - rand() * 10 },
      { x: safe.cx, y: safe.cy },
    ];

    // Severity score = share of dark pixels, roughly
    const avgLum = cells.reduce((s, c) => s + c.lum, 0) / cells.length;
    const severityScore = Math.round(Math.min(100, Math.max(0, (180 - avgLum) / 1.8)));

    return { zones, rescuePath, severityScore };
  } finally {
    URL.revokeObjectURL(url);
  }
}

function loadImage(src: string): Promise<HTMLImageElement> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = "anonymous";
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = src;
  });
}
