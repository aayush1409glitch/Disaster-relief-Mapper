import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Activity, MapPin, Route as RouteIcon, ShieldCheck, Phone, Radar } from "lucide-react";
import { UploadAnalyzer } from "@/components/UploadAnalyzer";
import { SosForm } from "@/components/SosForm";
import { RecentAssessments } from "@/components/RecentAssessments";
import { SheltersList } from "@/components/SheltersList";
import { StatsBar } from "@/components/StatsBar";
import { SosDashboard } from "@/components/SosDashboard";

export const Route = createFileRoute("/")({
  component: Index,
  head: () => ({
    meta: [
      { title: "ReliefMap — Rapid disaster zone assessment" },
      {
        name: "description",
        content:
          "Upload a satellite or drone image to instantly see high-, moderate- and low-damage zones, get a safer rescue path, and call nearby helplines.",
      },
      { property: "og:title", content: "ReliefMap — Rapid disaster zone assessment" },
      {
        property: "og:description",
        content:
          "Mark damaged areas, find a safer rescue path and reach helplines faster.",
      },
    ],
  }),
});

function Index() {
  const [savedId, setSavedId] = useState<string | null>(null);
  const [savedLoc, setSavedLoc] = useState<{ lat: number | null; lng: number | null; name: string | null }>({
    lat: null,
    lng: null,
    name: null,
  });
  const [refreshKey, setRefreshKey] = useState(0);

  return (
    <div className="min-h-screen text-foreground">
      <Toaster theme="dark" richColors position="top-center" />

      {/* Hero */}
      <header className="relative overflow-hidden bg-hero-gradient">
        {/* Decorative grid */}
        <div
          className="pointer-events-none absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "linear-gradient(to right, white 1px, transparent 1px), linear-gradient(to bottom, white 1px, transparent 1px)",
            backgroundSize: "48px 48px",
            maskImage: "radial-gradient(ellipse at center, black 50%, transparent 80%)",
          }}
        />
        <div className="relative mx-auto max-w-6xl px-5 py-5">
          <nav className="flex items-center justify-between">
            <div className="flex items-center gap-2 font-semibold">
              <span className="rounded-lg bg-white/10 p-1.5 ring-1 ring-white/20">
                <Activity className="h-5 w-5" />
              </span>
              ReliefMap
            </div>
            <div className="hidden items-center gap-1 text-sm md:flex">
              <NavA href="#analyze">Analyze</NavA>
              <NavA href="#dashboard">Dashboard</NavA>
              <NavA href="#sos">SOS</NavA>
              <NavA href="#resources">Resources</NavA>
            </div>
            <a
              href="#sos"
              className="rounded-full bg-alert-gradient px-4 py-1.5 text-sm font-semibold text-destructive-foreground shadow-glow-primary transition hover:opacity-95"
            >
              Emergency SOS
            </a>
          </nav>
        </div>
        <div className="relative mx-auto max-w-6xl px-5 pb-20 pt-10 sm:pb-28 sm:pt-16">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-2 rounded-full glass px-3 py-1 text-xs font-medium uppercase tracking-wider">
              <ShieldCheck className="h-3.5 w-3.5 text-primary" /> Rapid response toolkit
            </span>
            <h1 className="mt-4 text-4xl font-bold leading-tight tracking-tight sm:text-6xl">
              Map disaster damage in seconds.{" "}
              <span className="text-gradient-primary">Save lives faster.</span>
            </h1>
            <p className="mt-5 max-w-xl text-lg text-muted-foreground">
              Upload any satellite, drone or phone image of a disaster-hit zone. ReliefMap instantly highlights
              high, moderate and safer areas, suggests a rescue path, and connects victims to nearby help.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <Button asChild size="lg" className="shadow-glow-primary">
                <a href="#analyze">Analyze an image</a>
              </Button>
              <Button asChild size="lg" variant="outline" className="glass border-white/20 hover:bg-white/10">
                <a href="#dashboard">
                  <Radar className="mr-2 h-4 w-4" /> Live SOS dashboard
                </a>
              </Button>
            </div>
          </div>

          {/* Stats overlay at hero bottom */}
          <div className="mt-12">
            <StatsBar refreshKey={refreshKey} />
          </div>
        </div>
      </header>

      {/* Feature strip */}
      <section className="mx-auto max-w-6xl px-5 py-10">
        <div className="grid gap-3 rounded-2xl glass p-4 shadow-elevated sm:grid-cols-3">
          <Feature icon={<MapPin className="h-5 w-5" />} title="Auto-locate" desc="Reads GPS from photos or pick on a map" />
          <Feature icon={<Activity className="h-5 w-5" />} title="Damage zones" desc="Red, yellow and green ellipses on the image" />
          <Feature icon={<RouteIcon className="h-5 w-5" />} title="Rescue path" desc="Suggested safer route around hot zones" />
        </div>
      </section>

      {/* Analyze */}
      <section id="analyze" className="mx-auto max-w-6xl px-5 py-14">
        <SectionTitle eyebrow="Step 1" title="Upload & analyze" />
        <UploadAnalyzer
          onSaved={(id, loc) => {
            setSavedId(id);
            setSavedLoc(loc);
            setRefreshKey((k) => k + 1);
          }}
        />
      </section>

      {/* Live SOS Dashboard */}
      <section id="dashboard" className="mx-auto max-w-6xl px-5 py-14">
        <SectionTitle
          eyebrow="Live"
          title="SOS command dashboard"
          subtitle="Incoming distress reports update in real-time. Tap to call directly."
        />
        <SosDashboard refreshKey={refreshKey} />
      </section>

      {/* SOS */}
      <section id="sos" className="border-y border-white/5 bg-black/20 py-14 backdrop-blur-sm">
        <div className="mx-auto max-w-6xl px-5">
          <SectionTitle eyebrow="Step 2" title="Send an SOS" />
          <div className="grid gap-6 lg:grid-cols-2">
            <SosForm defaultLocation={savedLoc} assessmentId={savedId} />
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">Quick emergency numbers</h3>
              <div className="grid gap-2 sm:grid-cols-2">
                <QuickCall number="112" label="All-in-one Emergency" />
                <QuickCall number="108" label="Ambulance" />
                <QuickCall number="101" label="Fire" />
                <QuickCall number="100" label="Police" />
              </div>
              <p className="text-sm text-muted-foreground">
                If you're in immediate danger, call <strong className="text-foreground">112</strong> first. Use the SOS form to give responders extra context after.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Recent */}
      <section className="mx-auto max-w-6xl px-5 py-14">
        <SectionTitle eyebrow="Field reports" title="Recent assessments" />
        <RecentAssessments refreshKey={refreshKey} />
      </section>

      {/* Shelters */}
      <section id="resources" className="border-t border-white/5 bg-black/20 py-14 backdrop-blur-sm">
        <div className="mx-auto max-w-6xl px-5">
          <SectionTitle eyebrow="Resources" title="Shelters, hospitals & helplines" />
          <SheltersList />
        </div>
      </section>

      <footer className="border-t border-white/5 py-6 text-center text-sm text-muted-foreground">
        ReliefMap · Built to support rapid disaster response
      </footer>
    </div>
  );
}

function NavA({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <a
      href={href}
      className="rounded-full px-3 py-1.5 text-muted-foreground transition hover:bg-white/10 hover:text-foreground"
    >
      {children}
    </a>
  );
}

function SectionTitle({ eyebrow, title, subtitle }: { eyebrow: string; title: string; subtitle?: string }) {
  return (
    <div className="mb-6">
      <p className="text-xs font-semibold uppercase tracking-widest text-primary/80">{eyebrow}</p>
      <h2 className="mt-1 text-2xl font-bold tracking-tight sm:text-3xl">{title}</h2>
      {subtitle && <p className="mt-2 max-w-xl text-sm text-muted-foreground">{subtitle}</p>}
    </div>
  );
}

function Feature({ icon, title, desc }: { icon: React.ReactNode; title: string; desc: string }) {
  return (
    <div className="flex items-start gap-3 rounded-xl p-3">
      <span className="rounded-lg bg-primary/15 p-2 text-primary ring-1 ring-primary/30">{icon}</span>
      <div>
        <p className="font-semibold">{title}</p>
        <p className="text-sm text-muted-foreground">{desc}</p>
      </div>
    </div>
  );
}

function QuickCall({ number, label }: { number: string; label: string }) {
  return (
    <a
      href={`tel:${number}`}
      className="flex items-center justify-between rounded-xl glass px-4 py-3 transition hover:shadow-glow-primary"
    >
      <div>
        <p className="text-xs uppercase tracking-wider text-muted-foreground">{label}</p>
        <p className="text-xl font-bold">{number}</p>
      </div>
      <Phone className="h-5 w-5 text-primary" />
    </a>
  );
}
