import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Phone, MapPin, Users, Clock } from "lucide-react";

type Sos = {
  id: string;
  full_name: string;
  phone: string;
  people_count: number;
  situation: string;
  location_name: string | null;
  latitude: number | null;
  longitude: number | null;
  status: string;
  created_at: string;
};

export function SosDashboard({ refreshKey }: { refreshKey: number }) {
  const [items, setItems] = useState<Sos[]>([]);
  const [filter, setFilter] = useState<"all" | "pending">("pending");

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const { data } = await supabase
        .from("sos_reports")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(20);
      if (!cancelled) setItems(data ?? []);
    }
    load();

    const channel = supabase
      .channel("sos-live")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "sos_reports" },
        (payload) => {
          setItems((prev) => [payload.new as Sos, ...prev].slice(0, 20));
        },
      )
      .subscribe();

    return () => {
      cancelled = true;
      supabase.removeChannel(channel);
    };
  }, [refreshKey]);

  const visible = filter === "pending" ? items.filter((i) => i.status === "pending") : items;

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Button
          size="sm"
          variant={filter === "pending" ? "default" : "outline"}
          onClick={() => setFilter("pending")}
        >
          Pending
        </Button>
        <Button
          size="sm"
          variant={filter === "all" ? "default" : "outline"}
          onClick={() => setFilter("all")}
        >
          All
        </Button>
        <span className="ml-auto flex items-center gap-1.5 text-xs text-muted-foreground">
          <span className="relative flex h-2 w-2">
            <span className="absolute inline-flex h-full w-full animate-pulse-ring rounded-full bg-severity-high opacity-80" />
            <span className="relative inline-flex h-2 w-2 rounded-full" style={{ background: "var(--severity-high)" }} />
          </span>
          Live
        </span>
      </div>

      {visible.length === 0 ? (
        <Card className="glass border-0 p-8 text-center text-sm text-muted-foreground">
          No {filter === "pending" ? "pending " : ""}SOS reports yet.
        </Card>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {visible.map((s) => (
            <Card key={s.id} className="glass border-0 p-4 shadow-card-soft hover:shadow-glow-primary transition-shadow">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <p className="font-semibold">{s.full_name}</p>
                  <p className="mt-0.5 flex items-center gap-1 text-xs text-muted-foreground">
                    <Clock className="h-3 w-3" />
                    {new Date(s.created_at).toLocaleString()}
                  </p>
                </div>
                <Badge
                  className="capitalize"
                  style={{
                    backgroundColor:
                      s.status === "pending"
                        ? "color-mix(in oklab, var(--severity-high) 25%, transparent)"
                        : "color-mix(in oklab, var(--severity-low) 25%, transparent)",
                    color: s.status === "pending" ? "var(--severity-high)" : "var(--severity-low)",
                    border: "1px solid currentColor",
                  }}
                >
                  {s.status}
                </Badge>
              </div>

              <p className="mt-3 line-clamp-3 text-sm">{s.situation}</p>

              <div className="mt-3 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <Users className="h-3.5 w-3.5" /> {s.people_count}
                </span>
                {(s.location_name || (s.latitude && s.longitude)) && (
                  <span className="flex items-center gap-1">
                    <MapPin className="h-3.5 w-3.5" />
                    <span className="line-clamp-1 max-w-[180px]">
                      {s.location_name ?? `${s.latitude?.toFixed(3)}, ${s.longitude?.toFixed(3)}`}
                    </span>
                  </span>
                )}
              </div>

              <div className="mt-3 flex gap-2">
                <Button asChild size="sm" className="flex-1">
                  <a href={`tel:${s.phone}`}>
                    <Phone className="mr-1.5 h-3.5 w-3.5" /> {s.phone}
                  </a>
                </Button>
                {s.latitude && s.longitude && (
                  <Button asChild size="sm" variant="outline">
                    <a
                      href={`https://www.openstreetmap.org/?mlat=${s.latitude}&mlon=${s.longitude}#map=15/${s.latitude}/${s.longitude}`}
                      target="_blank"
                      rel="noopener noreferrer"
                    >
                      Map
                    </a>
                  </Button>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
