import type { AnalysisResult } from "@/lib/analyze";

type Props = {
  imageUrl: string;
  analysis: AnalysisResult;
};

const SEVERITY_COLOR: Record<"high" | "med" | "low", string> = {
  high: "var(--severity-high)",
  med: "var(--severity-med)",
  low: "var(--severity-low)",
};

export function DamageOverlay({ imageUrl, analysis }: Props) {
  const { zones, rescuePath } = analysis;

  const pathD = rescuePath
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`)
    .join(" ");

  return (
    <div className="relative w-full overflow-hidden rounded-2xl shadow-elevated bg-card">
      <img
        src={imageUrl}
        alt="Disaster zone analysis with marked severity areas"
        className="block h-auto w-full select-none"
      />
      <svg
        viewBox="0 0 100 100"
        preserveAspectRatio="none"
        className="pointer-events-none absolute inset-0 h-full w-full"
        aria-hidden="true"
      >
        {zones.map((z, i) => (
          <g key={i}>
            <ellipse
              cx={z.cx}
              cy={z.cy}
              rx={z.rx}
              ry={z.ry}
              transform={`rotate(${z.rotate} ${z.cx} ${z.cy})`}
              fill={SEVERITY_COLOR[z.severity]}
              fillOpacity={z.severity === "high" ? 0.28 : 0.22}
              stroke={SEVERITY_COLOR[z.severity]}
              strokeOpacity={0.95}
              strokeWidth={0.45}
              vectorEffect="non-scaling-stroke"
            />
          </g>
        ))}

        {/* Rescue path */}
        <path
          d={pathD}
          fill="none"
          stroke="var(--rescue)"
          strokeWidth={0.9}
          strokeDasharray="2 1.4"
          strokeLinecap="round"
          strokeLinejoin="round"
          vectorEffect="non-scaling-stroke"
          className="animate-dash"
        />
        {/* Start / end markers */}
        <circle cx={rescuePath[0].x} cy={rescuePath[0].y} r={1.4} fill="var(--rescue)" />
        <circle
          cx={rescuePath[rescuePath.length - 1].x}
          cy={rescuePath[rescuePath.length - 1].y}
          r={1.6}
          fill="var(--rescue)"
          stroke="white"
          strokeWidth={0.4}
          vectorEffect="non-scaling-stroke"
        />
      </svg>

      {/* Legend */}
      <div className="absolute bottom-3 left-3 flex flex-wrap gap-2 rounded-xl bg-card/90 px-3 py-2 text-xs shadow-card-soft backdrop-blur">
        <LegendDot color="var(--severity-high)" label="High" />
        <LegendDot color="var(--severity-med)" label="Moderate" />
        <LegendDot color="var(--severity-low)" label="Low" />
        <span className="mx-1 h-4 w-px bg-border" />
        <span className="flex items-center gap-1.5 text-muted-foreground">
          <span
            className="inline-block h-0.5 w-5 rounded"
            style={{
              background:
                "repeating-linear-gradient(90deg, var(--rescue) 0 4px, transparent 4px 7px)",
            }}
          />
          Rescue path
        </span>
      </div>
    </div>
  );
}

function LegendDot({ color, label }: { color: string; label: string }) {
  return (
    <span className="flex items-center gap-1.5 text-foreground">
      <span
        className="inline-block h-2.5 w-2.5 rounded-full"
        style={{ backgroundColor: color }}
      />
      {label}
    </span>
  );
}
