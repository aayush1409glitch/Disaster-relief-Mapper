import { useRef, useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Upload, Loader2, MapPin, RefreshCw, Save, Download, Share2 } from "lucide-react";
import { toast } from "sonner";
import * as htmlToImage from "html-to-image";
import { supabase } from "@/integrations/supabase/client";
import { analyzeImage, type AnalysisResult } from "@/lib/analyze";
import { extractGps, reverseGeocode } from "@/lib/exif";
import { DamageOverlay } from "./DamageOverlay";
import { LocationPicker } from "./LocationPicker";

type Props = {
  onSaved: (assessmentId: string, location: { lat: number | null; lng: number | null; name: string | null }) => void;
};

export function UploadAnalyzer({ onSaved }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const overlayRef = useRef<HTMLDivElement>(null);
  const [file, setFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [analysis, setAnalysis] = useState<AnalysisResult | null>(null);
  const [lat, setLat] = useState<number | null>(null);
  const [lng, setLng] = useState<number | null>(null);
  const [locationName, setLocationName] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [exporting, setExporting] = useState(false);

  async function exportPng() {
    if (!overlayRef.current) return;
    setExporting(true);
    try {
      const dataUrl = await htmlToImage.toPng(overlayRef.current, {
        cacheBust: true,
        pixelRatio: 2,
        backgroundColor: "#0b1220",
      });
      const link = document.createElement("a");
      link.download = `reliefmap-${Date.now()}.png`;
      link.href = dataUrl;
      link.click();
      toast.success("Report downloaded");
    } catch {
      toast.error("Could not export image");
    } finally {
      setExporting(false);
    }
  }

  async function shareReport() {
    if (!overlayRef.current) return;
    try {
      const blob = await htmlToImage.toBlob(overlayRef.current, { pixelRatio: 2, backgroundColor: "#0b1220" });
      if (!blob) throw new Error("blob");
      const fileToShare = new File([blob], "reliefmap-report.png", { type: "image/png" });
      const nav = navigator as Navigator & { canShare?: (d: ShareData) => boolean };
      if (nav.canShare?.({ files: [fileToShare] })) {
        await nav.share({
          files: [fileToShare],
          title: "ReliefMap damage assessment",
          text: locationName ? `Damage assessment near ${locationName}` : "Damage assessment from ReliefMap",
        });
      } else {
        await navigator.clipboard.writeText(window.location.href);
        toast.success("Link copied to clipboard");
      }
    } catch {
      toast.error("Sharing not available on this device");
    }
  }

  async function onFileChosen(f: File) {
    if (!f.type.startsWith("image/")) {
      toast.error("Please choose an image file.");
      return;
    }
    if (f.size > 10 * 1024 * 1024) {
      toast.error("Image must be under 10 MB.");
      return;
    }
    setLoading(true);
    setFile(f);
    setAnalysis(null);
    setLat(null);
    setLng(null);
    setLocationName(null);
    if (previewUrl) URL.revokeObjectURL(previewUrl);
    const url = URL.createObjectURL(f);
    setPreviewUrl(url);

    try {
      const [result, gps] = await Promise.all([analyzeImage(f), extractGps(f)]);
      setAnalysis(result);
      if (gps) {
        setLat(gps.latitude);
        setLng(gps.longitude);
        const name = await reverseGeocode(gps.latitude, gps.longitude);
        setLocationName(name);
      }
    } catch {
      toast.error("Could not analyze that image.");
    } finally {
      setLoading(false);
    }
  }

  async function applyManualLocation(la: number, ln: number) {
    setLat(la);
    setLng(ln);
    const name = await reverseGeocode(la, ln);
    setLocationName(name);
  }

  async function reAnalyze() {
    if (!file) return;
    setLoading(true);
    try {
      // Re-run on a slightly modified File to get a different seed
      const renamed = new File([file], `${Date.now()}-${file.name}`, { type: file.type });
      setFile(renamed);
      const result = await analyzeImage(renamed);
      setAnalysis(result);
    } finally {
      setLoading(false);
    }
  }

  async function save() {
    if (!file || !analysis) return;
    setSaving(true);
    try {
      const ext = file.name.split(".").pop()?.toLowerCase() || "jpg";
      const path = `uploads/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
      const up = await supabase.storage.from("disaster-images").upload(path, file, {
        cacheControl: "3600",
        upsert: false,
      });
      if (up.error) throw up.error;
      const { data: pub } = supabase.storage.from("disaster-images").getPublicUrl(path);
      const { data, error } = await supabase
        .from("assessments")
        .insert({
          image_url: pub.publicUrl,
          location_name: locationName,
          latitude: lat,
          longitude: lng,
          zones: analysis.zones,
          rescue_path: analysis.rescuePath,
          severity_score: analysis.severityScore,
        })
        .select("id")
        .single();
      if (error) throw error;
      toast.success("Assessment saved");
      onSaved(data.id, { lat, lng, name: locationName });
    } catch (err) {
      console.error(err);
      toast.error("Could not save assessment");
    } finally {
      setSaving(false);
    }
  }

  const sev = analysis?.severityScore ?? 0;
  const sevColor = sev > 60 ? "var(--severity-high)" : sev > 30 ? "var(--severity-med)" : "var(--severity-low)";

  return (
    <Card className="glass border-0 p-5 space-y-5 shadow-elevated">
      {!previewUrl && (
        <button
          type="button"
          onClick={() => inputRef.current?.click()}
          className="group flex w-full flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed border-white/15 bg-white/5 px-6 py-14 text-center transition-all hover:border-primary hover:bg-white/10"
        >
          <span className="rounded-full bg-primary/20 p-4 text-primary group-hover:scale-110 transition-transform">
            <Upload className="h-7 w-7" />
          </span>
          <div>
            <p className="text-base font-semibold">Upload disaster zone image</p>
            <p className="text-sm text-muted-foreground">
              Satellite, drone, or phone photo · JPG / PNG up to 10 MB
            </p>
          </div>
        </button>
      )}

      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        className="hidden"
        onChange={(e) => {
          const f = e.target.files?.[0];
          if (f) void onFileChosen(f);
        }}
      />

      {previewUrl && (
        <div className="space-y-4">
          <div ref={overlayRef} className="relative">
            {loading && (
              <div className="absolute inset-0 z-10 flex items-center justify-center rounded-2xl bg-background/80 backdrop-blur-sm">
                <div className="flex items-center gap-2 rounded-full glass px-4 py-2">
                  <Loader2 className="h-4 w-4 animate-spin" />
                  <span className="text-sm font-medium">Analyzing image…</span>
                </div>
              </div>
            )}
            {analysis ? (
              <DamageOverlay imageUrl={previewUrl} analysis={analysis} />
            ) : (
              <img src={previewUrl} alt="Preview" className="w-full rounded-2xl" />
            )}
          </div>

          {analysis && (
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl glass p-3">
              <div className="flex items-center gap-3">
                <Badge style={{ backgroundColor: sevColor, color: "#0b1220" }} className="text-sm font-semibold">
                  Severity {sev}/100
                </Badge>
                {locationName ? (
                  <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    <span className="line-clamp-1 max-w-[260px]">{locationName}</span>
                  </span>
                ) : lat != null && lng != null ? (
                  <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
                    <MapPin className="h-4 w-4" />
                    {lat.toFixed(4)}, {lng.toFixed(4)}
                  </span>
                ) : null}
              </div>
              <div className="flex flex-wrap gap-2">
                <Button variant="outline" size="sm" onClick={reAnalyze}>
                  <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Re-analyze
                </Button>
                <Button variant="outline" size="sm" onClick={exportPng} disabled={exporting}>
                  <Download className="mr-1.5 h-3.5 w-3.5" /> {exporting ? "…" : "PNG"}
                </Button>
                <Button variant="outline" size="sm" onClick={shareReport}>
                  <Share2 className="mr-1.5 h-3.5 w-3.5" /> Share
                </Button>
                <Button size="sm" onClick={save} disabled={saving} className="shadow-glow-primary">
                  <Save className="mr-1.5 h-3.5 w-3.5" /> {saving ? "Saving…" : "Save"}
                </Button>
              </div>
            </div>
          )}

          {analysis && lat == null && (
            <LocationPicker initialLat={null} initialLng={null} onChange={applyManualLocation} />
          )}

          <div className="flex justify-center">
            <Button variant="ghost" size="sm" onClick={() => inputRef.current?.click()}>
              Choose a different image
            </Button>
          </div>
        </div>
      )}
    </Card>
  );
}
