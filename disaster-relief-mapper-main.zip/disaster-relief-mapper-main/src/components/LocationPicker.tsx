import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";

type Props = {
  initialLat: number | null;
  initialLng: number | null;
  onChange: (lat: number, lng: number) => void;
};

export function LocationPicker({ initialLat, initialLng, onChange }: Props) {
  const [lat, setLat] = useState<string>(initialLat?.toString() ?? "");
  const [lng, setLng] = useState<string>(initialLng?.toString() ?? "");

  const useMyLocation = () => {
    if (!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition((pos) => {
      setLat(pos.coords.latitude.toFixed(6));
      setLng(pos.coords.longitude.toFixed(6));
      onChange(pos.coords.latitude, pos.coords.longitude);
    });
  };

  const apply = () => {
    const la = parseFloat(lat);
    const ln = parseFloat(lng);
    if (isFinite(la) && isFinite(ln) && la >= -90 && la <= 90 && ln >= -180 && ln <= 180) {
      onChange(la, ln);
    }
  };

  return (
    <Card className="p-4 space-y-3">
      <div className="flex items-center justify-between">
        <p className="text-sm font-medium">Location not found in photo</p>
        <Button type="button" size="sm" variant="secondary" onClick={useMyLocation}>
          Use my location
        </Button>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <Label htmlFor="lat" className="text-xs">Latitude</Label>
          <Input
            id="lat"
            inputMode="decimal"
            value={lat}
            onChange={(e) => setLat(e.target.value)}
            placeholder="e.g. 28.6139"
          />
        </div>
        <div>
          <Label htmlFor="lng" className="text-xs">Longitude</Label>
          <Input
            id="lng"
            inputMode="decimal"
            value={lng}
            onChange={(e) => setLng(e.target.value)}
            placeholder="e.g. 77.2090"
          />
        </div>
      </div>
      <Button type="button" onClick={apply} className="w-full" variant="outline">
        Apply location
      </Button>
    </Card>
  );
}
