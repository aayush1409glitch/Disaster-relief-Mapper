import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Activity, AlertOctagon, Flame, Gauge } from "lucide-react";

type Stats = {
  total: number;
  highRisk: number;
  activeSos: number;
  avgSeverity: number;
};

export function StatsBar({ refreshKey }: { refreshKey: number }) {
  const [stats, setStats] = useState<Stats>({ total: 0, highRisk: 0, activeSos: 0, avgSeverity: 0 });

  useEffect(() => {
    let cancelled = false;
    async function load() {
      const [{ data: assess }, { data: sos }] = await Promise.all([
        supabase.from("assessments").select("severity_score"),
        supabase.from("sos_reports").select("status"),
      ]);
      if (cancelled) return;
      const scores = (assess ?? []).map((a) => a.severity_score ?? 0);
      const total = scores.length;
      const highRisk = scores.filter((s) => s > 60).length;
      const avg = total ? Math.round(scores.reduce((a, b) => a + b, 0) / total) : 0;
      const activeSos = (sos ?? []).filter((s) => s.status === "pending").length;
      setStats({ total, highRisk, activeSos, avgSeverity: avg });
    }
    load();
    return () => {
      cancelled = true;
    };
  }, [refreshKey]);

  const items = [
    { icon: <Activity className="h-4 w-4" />, label: "Assessments", value: stats.total, color: "var(--primary)" },
    { icon: <Flame className="h-4 w-4" />, label: "High-risk zones", value: stats.highRisk, color: "var(--severity-high)" },
    { icon: <AlertOctagon className="h-4 w-4" />, label: "Active SOS", value: stats.activeSos, color: "var(--severity-med)" },
    { icon: <Gauge className="h-4 w-4" />, label: "Avg severity", value: stats.avgSeverity, color: "var(--severity-low)" },
  ];

  return (
    <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
      {items.map((it) => (
        <Card key={it.label} className="glass shadow-card-soft p-4 border-0">
          <div className="flex items-center gap-2 text-xs uppercase tracking-wider text-muted-foreground">
            <span className="rounded-md p-1.5" style={{ backgroundColor: `color-mix(in oklab, ${it.color} 20%, transparent)`, color: it.color }}>
              {it.icon}
            </span>
            {it.label}
          </div>
          <p className="mt-2 text-3xl font-bold tracking-tight" style={{ color: it.color }}>
            {it.value}
          </p>
        </Card>
      ))}
    </div>
  );
}
