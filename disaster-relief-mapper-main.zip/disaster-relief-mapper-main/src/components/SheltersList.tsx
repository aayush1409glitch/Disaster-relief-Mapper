import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, Hospital, Home, AlertTriangle } from "lucide-react";

type Shelter = {
  id: string;
  name: string;
  type: string;
  phone: string | null;
  address: string | null;
  capacity: number | null;
};

const ICONS: Record<string, React.ReactNode> = {
  shelter: <Home className="h-4 w-4" />,
  hospital: <Hospital className="h-4 w-4" />,
  helpline: <AlertTriangle className="h-4 w-4" />,
};

export function SheltersList() {
  const [shelters, setShelters] = useState<Shelter[]>([]);

  useEffect(() => {
    supabase
      .from("shelters")
      .select("id, name, type, phone, address, capacity")
      .order("type")
      .then(({ data }) => setShelters(data ?? []));
  }, []);

  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {shelters.map((s) => (
        <Card key={s.id} className="glass border-0 p-4 hover:shadow-glow-primary transition-shadow">
          <div className="flex items-start justify-between gap-2">
            <div className="flex items-center gap-2">
              <span className="rounded-lg bg-primary/15 p-2 text-primary">
                {ICONS[s.type] ?? <AlertTriangle className="h-4 w-4" />}
              </span>
              <div>
                <p className="font-semibold leading-tight">{s.name}</p>
                <p className="text-xs text-muted-foreground">{s.address}</p>
              </div>
            </div>
            <Badge variant="secondary" className="capitalize">{s.type}</Badge>
          </div>
          {s.phone && (
            <a
              href={`tel:${s.phone}`}
              className="mt-3 inline-flex items-center gap-2 text-sm font-medium text-primary hover:underline"
            >
              <Phone className="h-3.5 w-3.5" /> {s.phone}
            </a>
          )}
          {s.capacity && (
            <p className="mt-1 text-xs text-muted-foreground">Capacity: {s.capacity} people</p>
          )}
        </Card>
      ))}
    </div>
  );
}
