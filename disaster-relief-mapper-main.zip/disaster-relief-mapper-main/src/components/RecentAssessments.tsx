import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin } from "lucide-react";

type Item = {
  id: string;
  image_url: string;
  location_name: string | null;
  severity_score: number;
  created_at: string;
};

export function RecentAssessments({ refreshKey }: { refreshKey: number }) {
  const [items, setItems] = useState<Item[]>([]);

  useEffect(() => {
    supabase
      .from("assessments")
      .select("id, image_url, location_name, severity_score, created_at")
      .order("created_at", { ascending: false })
      .limit(6)
      .then(({ data }) => setItems(data ?? []));
  }, [refreshKey]);

  if (items.length === 0) {
    return (
      <Card className="glass border-0 p-6 text-center text-sm text-muted-foreground">
        No assessments yet. Upload your first disaster image above.
      </Card>
    );
  }

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((it) => {
        const sev = it.severity_score;
        const sevColor = sev > 60 ? "var(--severity-high)" : sev > 30 ? "var(--severity-med)" : "var(--severity-low)";
        return (
          <Card key={it.id} className="glass border-0 overflow-hidden hover:shadow-glow-primary transition-shadow">
            <div className="aspect-video w-full overflow-hidden bg-black/30">
              <img src={it.image_url} alt="Assessment" className="h-full w-full object-cover" />
            </div>
            <div className="space-y-2 p-3">
              <div className="flex items-center justify-between">
                <Badge style={{ backgroundColor: sevColor, color: "#0b1220" }}>
                  Severity {sev}
                </Badge>
                <span className="text-xs text-muted-foreground">
                  {new Date(it.created_at).toLocaleString()}
                </span>
              </div>
              <p className="flex items-start gap-1.5 text-sm text-muted-foreground">
                <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                <span className="line-clamp-2">{it.location_name ?? "Unknown location"}</span>
              </p>
            </div>
          </Card>
        );
      })}
    </div>
  );
}
