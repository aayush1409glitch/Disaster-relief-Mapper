import { useState } from "react";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import { Siren } from "lucide-react";

const sosSchema = z.object({
  full_name: z.string().trim().min(1, "Name required").max(120),
  phone: z.string().trim().min(4, "Phone required").max(20).regex(/^[0-9+\-\s()]+$/, "Invalid phone"),
  people_count: z.coerce.number().int().min(1).max(1000),
  situation: z.string().trim().min(5, "Describe situation").max(1000),
  location_name: z.string().trim().max(200).optional().or(z.literal("")),
});

type Props = {
  defaultLocation?: { lat: number | null; lng: number | null; name: string | null };
  assessmentId?: string | null;
};

export function SosForm({ defaultLocation, assessmentId }: Props) {
  const [submitting, setSubmitting] = useState(false);

  async function onSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = new FormData(e.currentTarget);
    const parsed = sosSchema.safeParse(Object.fromEntries(form));
    if (!parsed.success) {
      toast.error(parsed.error.issues[0]?.message ?? "Please check the form");
      return;
    }
    setSubmitting(true);
    const { error } = await supabase.from("sos_reports").insert({
      full_name: parsed.data.full_name,
      phone: parsed.data.phone,
      people_count: parsed.data.people_count,
      situation: parsed.data.situation,
      location_name: parsed.data.location_name || defaultLocation?.name || null,
      latitude: defaultLocation?.lat ?? null,
      longitude: defaultLocation?.lng ?? null,
      assessment_id: assessmentId ?? null,
    });
    setSubmitting(false);
    if (error) {
      toast.error("Could not send SOS. Please try again.");
      return;
    }
    toast.success("SOS sent. Rescue teams have been notified.");
    (e.target as HTMLFormElement).reset();
  }

  return (
    <Card className="glass border-0 overflow-hidden shadow-elevated">
      <div className="bg-alert-gradient px-5 py-4 text-destructive-foreground">
        <div className="flex items-center gap-2">
          <Siren className="h-5 w-5" />
          <h3 className="text-lg font-semibold">Send an SOS</h3>
        </div>
        <p className="text-sm opacity-90">For people trapped or needing urgent rescue</p>
      </div>
      <form onSubmit={onSubmit} className="space-y-3 p-5">
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label htmlFor="full_name">Full name</Label>
            <Input id="full_name" name="full_name" maxLength={120} required />
          </div>
          <div>
            <Label htmlFor="phone">Phone</Label>
            <Input id="phone" name="phone" type="tel" maxLength={20} required />
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-2">
          <div>
            <Label htmlFor="people_count">People with you</Label>
            <Input id="people_count" name="people_count" type="number" min={1} max={1000} defaultValue={1} required />
          </div>
          <div>
            <Label htmlFor="location_name">Location (landmark)</Label>
            <Input id="location_name" name="location_name" maxLength={200} placeholder="Optional" />
          </div>
        </div>
        <div>
          <Label htmlFor="situation">Situation</Label>
          <Textarea id="situation" name="situation" rows={3} maxLength={1000} required placeholder="Trapped on 2nd floor, water rising..." />
        </div>
        <Button type="submit" disabled={submitting} className="w-full bg-alert-gradient text-destructive-foreground hover:opacity-95">
          {submitting ? "Sending…" : "Send SOS now"}
        </Button>
      </form>
    </Card>
  );
}
